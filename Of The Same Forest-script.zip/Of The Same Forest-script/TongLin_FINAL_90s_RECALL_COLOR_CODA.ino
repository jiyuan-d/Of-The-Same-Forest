#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>
#include <Adafruit_MPR121.h>
#include <FastLED.h>
#include <DFRobotDFPlayerMini.h>
#include <HardwareSerial.h>

#define TEST_MODE false

#define STARTUP_GUARD_MS       3000UL

#define USE_IDLE_05 false

const unsigned long STAGE_MIN_MS =
  TEST_MODE ? 20000UL : 90000UL;
const unsigned long FADEOUT_MS =
  TEST_MODE ? 3000UL : 7000UL;
const unsigned long MANUAL_END_HOLD_MS = 3000UL;
const unsigned long BLACK_RESET_HOLD_MS = 5000UL;
const unsigned long CODA_04_DELAY_MS =
  TEST_MODE ? 1800UL : 3000UL;
const unsigned long CODA_05_DELAY_MS =
  TEST_MODE ? 6000UL : 12000UL;

const unsigned long SOLO_BREATH_START_MS =
  TEST_MODE ? 8000UL : 40000UL;

const unsigned long CHORUS_BREATH_START_MS =
  TEST_MODE ? 4000UL : 20000UL;

const unsigned long CHORUS_BREATH_DURATION_MS =
  TEST_MODE ? 8000UL : 40000UL;

const unsigned long SHARED_BREATH_PERIOD_MS =
  TEST_MODE ? 4000UL : 8000UL;

#define USE_CODA_04 true
#define USE_CODA_05 true

#define USE_RECALL_ADVERT true
const unsigned long RECALL_COOLDOWN_MS =
  TEST_MODE ? 2200UL : 5000UL;
const unsigned long RECALL_RESPONSE_DELAY_MS =
  TEST_MODE ? 900UL : 2600UL;

#define PIN_SDA       26
#define PIN_SCL       32

#define PIN_CORD_E0   23
#define PIN_CORD_E1   21
#define PIN_CORD_E2   33
#define PIN_ISLAND    25

#define DF_RX_PIN     19
#define DF_TX_PIN     22

#define CH_COB        0
#define CH_KEYES      3

#define NUM_E0        160
#define NUM_E1        160
#define NUM_E2        160
#define NUM_ISLAND    40

#define LED_MASTER    58

const uint8_t TOUCH_ON_LEVEL[3]  = {8, 8, 8};
const uint8_t TOUCH_OFF_LEVEL[3] = {10, 10, 10};

#define TOUCH_DEBOUNCE_MS 80UL
#define E2_RELEASE_READY_MS 800UL
#define SERIAL_REPORT_MS  300UL

const unsigned long IDLE_CALL_MIN_MS =
  TEST_MODE ? 10000UL : 60000UL;
const unsigned long IDLE_CALL_MAX_MS =
  TEST_MODE ? 15000UL : 90000UL;

#define DF_VOLUME 25

#define AUDIO_STOP_GAP_MS 350UL
#define AUDIO_PLAY_SETTLE_MS 120UL

const float KEYES_IDLE    = 0.00f;
const float KEYES_SOLO    = 0.00f;
const float KEYES_DUET    = 0.00f;
const float KEYES_CHORUS  = 0.00f;

const float COB_IDLE      = 0.00f;
const float COB_SOLO      = 0.18f;
const float COB_DUET      = 0.24f;
const float COB_CHORUS    = 0.32f;

const CHSV COL_E0 = CHSV(145, 190, 210);
const CHSV COL_E1 = CHSV( 96, 205, 200);
const CHSV COL_E2 = CHSV( 18, 235, 175);

const CHSV COL_ISLAND_IDLE   = CHSV(135, 75, 255);
const CHSV COL_ISLAND_SOLO   = CHSV(122, 90, 255);
const CHSV COL_ISLAND_DUET   = CHSV( 82, 75, 255);
const CHSV COL_ISLAND_CHORUS = CHSV( 30, 55, 255);

const bool ISLAND_AT_INDEX_0[3] = {
  true,
  true,
  true
};

const float PULSE_GAIN[3] = {
  1.00f,
  0.92f,
  0.70f
};

#define PULSE_SIGMA 6.0f

unsigned long lightingSeqNextAt = 0;
uint8_t lightingSeqStep = 0;
uint8_t lightingTimelineZone = 255;
float cobAccent = 0.0f;

struct RecallEvent {
  bool active;
  uint8_t source;
  uint8_t target;
  unsigned long responseAt;
};

RecallEvent recallEvents[2] = {
  {false, 0, 0, 0},
  {false, 1, 1, 0}
};

unsigned long lastRecallAt[2] = {0, 0};

Adafruit_PWMServoDriver pwm = Adafruit_PWMServoDriver(0x40);
Adafruit_MPR121 cap = Adafruit_MPR121();

HardwareSerial dfSerial(1);
DFRobotDFPlayerMini dfplayer;

bool capOK = false;
bool dfOK = false;

CRGB ledsE0[NUM_E0];
CRGB ledsE1[NUM_E1];
CRGB ledsE2[NUM_E2];
CRGB ledsIsland[NUM_ISLAND];

#define MAX_PULSES 5

struct Pulse {
  float pos;
  float vel;
  float intensity;
  bool alive;
};

struct Cord {
  CRGB* leds;
  int n;
  CHSV color;
  Pulse pulses[MAX_PULSES];
  float baseGlow;
  float glowTarget;
};

Cord cords[3];
Cord island;

enum State {
  S_IDLE,
  S_SOLO,
  S_DUET,
  S_CHORUS,
  S_FADEOUT,
  S_BLACK
};

State state = S_IDLE;
unsigned long stateSince = 0;
unsigned long lastFrame = 0;
float dt = 0.0f;

bool held[3] = {false, false, false};
bool rawCandidate[3] = {false, false, false};
bool prevHeld[3] = {false, false, false};
unsigned long candidateSince[3] = {0, 0, 0};
bool e2Ready = false;
unsigned long e2ReleasedSince = 0;

bool touchSystemArmed = false;
unsigned long touchGuardUntil = 0;

bool nextTouchArmed = false;

bool chorusAudioFinished = false;
bool manualEndArmed = false;
unsigned long manualEndHeldSince = 0;

bool coda04Played = false;
bool coda05Played = false;
unsigned long blackResetSince = 0;

unsigned long nextIdleCallAt = 0;

int currentFolder = -1;
int currentFile = -1;

unsigned long lastSerialReport = 0;

const char* stateName(State s) {
  switch (s) {
    case S_IDLE:    return "IDLE";
    case S_SOLO:    return "SOLO";
    case S_DUET:    return "DUET";
    case S_CHORUS:  return "CHORUS";
    case S_FADEOUT: return "FADEOUT";
    case S_BLACK:   return "BLACK";
    default:        return "?";
  }
}

float raisedSine(unsigned long periodMs, unsigned long phaseMs = 0) {
  unsigned long t = (millis() + phaseMs) % periodMs;
  return 0.5f - 0.5f * cosf(
    2.0f * PI * (float)t / (float)periodMs
  );
}

float softPhaseSine(
  unsigned long periodMs,
  unsigned long phaseMs
) {
  return 0.5f - 0.5f * cosf(
    2.0f * PI *
    (float)((millis() + phaseMs) % periodMs) /
    (float)periodMs
  );
}

void pulseIslandToPerson(
  int cordIndex,
  float speed,
  float intensity
) {
  Cord &c = cords[cordIndex];

  if (ISLAND_AT_INDEX_0[cordIndex]) {
    spawnPulse(c, 0.0f, speed, intensity * PULSE_GAIN[cordIndex]);
  } else {
    spawnPulse(c, (float)(c.n - 1), -speed, intensity * PULSE_GAIN[cordIndex]);
  }
}

void pulsePersonToIsland(
  int cordIndex,
  float speed,
  float intensity
) {
  Cord &c = cords[cordIndex];

  if (ISLAND_AT_INDEX_0[cordIndex]) {
    spawnPulse(c, (float)(c.n - 1), -speed, intensity * PULSE_GAIN[cordIndex]);
  } else {
    spawnPulse(c, 0.0f, speed, intensity * PULSE_GAIN[cordIndex]);
  }
}

void resetLightingSequence() {
  lightingSeqStep = 0;
  lightingTimelineZone = 255;
  lightingSeqNextAt = millis() + 120UL;
  cobAccent = 0.0f;
}

void clearRecallEvents() {
  for (int i = 0; i < 2; i++) {
    recallEvents[i].active = false;
    recallEvents[i].responseAt = 0;
  }
}

void playRecallAdvert(uint8_t source) {
  if (!USE_RECALL_ADVERT || !dfOK) return;

  uint16_t advertFile = (source == 0) ? 1 : 2;
  dfplayer.advertise(advertFile);

  Serial.print("ADVERT追加呼喊：/ADVERT/000");
  Serial.print(advertFile);
  Serial.println(".mp3");
}

void triggerRecall(uint8_t source) {
  if (source > 1) return;

  unsigned long now = millis();

  if (
    now - lastRecallAt[source] <
    RECALL_COOLDOWN_MS
  ) {
    Serial.print("E");
    Serial.print(source);
    Serial.println("追加呼喊仍在冷却");
    return;
  }

  if (recallEvents[source].active) return;

  uint8_t target = source;

  if (state == S_DUET) {
    target = (source == 0) ? 1 : 0;
  }

  lastRecallAt[source] = now;

  recallEvents[source].active = true;
  recallEvents[source].source = source;
  recallEvents[source].target = target;
  recallEvents[source].responseAt =
    now + RECALL_RESPONSE_DELAY_MS;

  pulsePersonToIsland(source, 48.0f, 0.92f);
  cobAccent = max(cobAccent, 0.18f);

  playRecallAdvert(source);

  Serial.print("E");
  Serial.print(source);
  Serial.print("追加呼喊：人→岛，稍后岛→E");
  Serial.println(target);
}

void updateRecallEvents() {
  unsigned long now = millis();

  for (int i = 0; i < 2; i++) {
    if (!recallEvents[i].active) continue;

    if (
      (long)(now - recallEvents[i].responseAt) >= 0
    ) {
      cobAccent = max(cobAccent, 0.40f);

      pulseIslandToPerson(
        recallEvents[i].target,
        42.0f,
        0.80f
      );

      recallEvents[i].active = false;

      Serial.print("岛心回应 → E");
      Serial.println(recallEvents[i].target);
    }
  }
}

void writePCA(int channel, float level) {
  level = constrain(level, 0.0f, 1.0f);
  int value = (int)(powf(level, 2.2f) * 4095.0f);
  pwm.setPWM(channel, 0, value);
}

void initCord(Cord &c, CRGB* leds, int n, CHSV color) {
  c.leds = leds;
  c.n = n;
  c.color = color;
  c.baseGlow = 0.0f;
  c.glowTarget = 0.0f;

  for (int i = 0; i < MAX_PULSES; i++) {
    c.pulses[i].pos = 0.0f;
    c.pulses[i].vel = 0.0f;
    c.pulses[i].intensity = 0.0f;
    c.pulses[i].alive = false;
  }
}

void clearCordPulses(Cord &c) {
  for (int i = 0; i < MAX_PULSES; i++) {
    c.pulses[i].alive = false;
  }
}

void spawnPulse(Cord &c, float pos, float vel, float intensity) {
  for (int i = 0; i < MAX_PULSES; i++) {
    if (!c.pulses[i].alive) {
      c.pulses[i].pos = pos;
      c.pulses[i].vel = vel;
      c.pulses[i].intensity = intensity;
      c.pulses[i].alive = true;
      return;
    }
  }
}

void islandAnswer(float intensity) {
  (void)intensity;
}

void setIslandColorForState() {
  switch (state) {
    case S_IDLE:
      island.color = COL_ISLAND_IDLE;
      break;
    case S_SOLO:
      island.color = COL_ISLAND_SOLO;
      break;
    case S_DUET:
      island.color = COL_ISLAND_DUET;
      break;
    case S_CHORUS:
    case S_FADEOUT:
      island.color = COL_ISLAND_CHORUS;
      break;
    default:
      island.color = COL_ISLAND_IDLE;
      break;
  }
}

void playTrack(int folder, int file) {
  currentFolder = folder;
  currentFile = file;

  if (!dfOK) {
    Serial.print("音频跳过：DFPlayer 未连接，目标 /");
    Serial.print(folder);
    Serial.print("/00");
    Serial.print(file);
    Serial.println(".mp3");
    return;
  }

  dfplayer.stop();
  delay(AUDIO_STOP_GAP_MS);

  dfplayer.playFolder(folder, file);
  delay(AUDIO_PLAY_SETTLE_MS);

  Serial.print("已停止上一首，并请求播放 /");
  if (folder < 10) Serial.print("0");
  Serial.print(folder);
  Serial.print("/");
  if (file < 100) Serial.print("0");
  if (file < 10) Serial.print("0");
  Serial.print(file);
  Serial.println(".mp3");
}

void stopAudio() {
  currentFolder = -1;
  currentFile = -1;

  if (dfOK) {
    dfplayer.stop();
  }
}

void pollAudio() {
  if (!dfOK || !dfplayer.available()) return;

  uint8_t type = dfplayer.readType();
  int value = dfplayer.read();

  if (type == DFPlayerPlayFinished) {
    Serial.print("音频播放结束，文件编号：");
    Serial.println(value);

    if (state == S_CHORUS && currentFolder == 3) {
      chorusAudioFinished = true;
      Serial.println("03 已结束：达到 CHORUS 最短时间后进入渐黑");
    }
  }
}

bool rawTouchForElectrode(int i, uint16_t filtered) {
  if (held[i]) {
    return filtered < TOUCH_OFF_LEVEL[i];
  }

  return filtered <= TOUCH_ON_LEVEL[i];
}

void readTouch() {
  unsigned long now = millis();

  if (!touchSystemArmed) {
    for (int i = 0; i < 3; i++) {
      held[i] = false;
      prevHeld[i] = false;
      rawCandidate[i] = false;
      candidateSince[i] = now;
    }

    if (!capOK || (long)(now - touchGuardUntil) < 0) {
      return;
    }

    touchSystemArmed = true;
    Serial.println("触摸系统已解锁：armed=1，现在可触摸 E0 开场");
    return;
  }

  for (int i = 0; i < 3; i++) {
    prevHeld[i] = held[i];

    if (!capOK) {
      held[i] = false;
      continue;
    }

    uint16_t filtered = cap.filteredData(i);
    bool raw = rawTouchForElectrode(i, filtered);

    if (raw != rawCandidate[i]) {
      rawCandidate[i] = raw;
      candidateSince[i] = now;
    }

    if (
      rawCandidate[i] != held[i] &&
      now - candidateSince[i] >= TOUCH_DEBOUNCE_MS
    ) {
      held[i] = rawCandidate[i];
    }
  }

  for (int i = 0; i < 3; i++) {
    if (held[i] && !prevHeld[i]) {
      Serial.print("触摸 E");
      Serial.println(i);
    }
  }
}

void scheduleNextIdleCall() {
  nextIdleCallAt = millis() + random(
    IDLE_CALL_MIN_MS,
    IDLE_CALL_MAX_MS + 1
  );
}

void enterState(State nextState) {
  state = nextState;
  stateSince = millis();
  nextTouchArmed = false;
  e2Ready = false;
  e2ReleasedSince = 0;
  resetLightingSequence();
  clearRecallEvents();

  setIslandColorForState();

  switch (state) {
    case S_IDLE:
      stopAudio();
      chorusAudioFinished = false;
      manualEndArmed = false;
      manualEndHeldSince = 0;
      coda04Played = false;
      coda05Played = false;
      blackResetSince = 0;
      scheduleNextIdleCall();

      for (int i = 0; i < 3; i++) {
        cords[i].baseGlow = 0.0f;
        cords[i].glowTarget = 0.0f;
        clearCordPulses(cords[i]);
      }

      island.baseGlow = 0.0f;
      island.glowTarget = 0.0f;
      clearCordPulses(island);

      Serial.println("→ IDLE");
      break;

    case S_SOLO:
      playTrack(1, 1);
      cobAccent = 0.12f;
      Serial.println("→ SOLO：岛心呼唤，E0由岛向人");
      break;

    case S_DUET:
      playTrack(2, 1);
      Serial.println("→ DUET：E1向岛，岛再向两人回应");
      break;

    case S_CHORUS:
      playTrack(3, 1);
      chorusAudioFinished = false;
      manualEndArmed = false;
      manualEndHeldSince = 0;

      Serial.println("→ CHORUS：三声汇聚、扩散与复调漂移");
      Serial.println("03 播完后自动渐黑；备用：最短时间后重新长按 E2 三秒");
      break;

    case S_FADEOUT:
      stopAudio();
      manualEndHeldSince = 0;
      Serial.println("→ FADEOUT：7 秒渐黑");
      break;

    case S_BLACK:
      stopAudio();
      coda04Played = false;
      coda05Played = false;
      blackResetSince = 0;
      Serial.println("→ BLACK：保持黑场");
      Serial.println("黑场中同时长按 E0 + E2 五秒，可回到 IDLE");
      break;
  }
}

void updateStateMachine() {
  unsigned long now = millis();
  unsigned long elapsed = now - stateSince;

  switch (state) {
    case S_IDLE:
      if (USE_IDLE_05 && (long)(now - nextIdleCallAt) >= 0) {
        playTrack(5, 1);
        scheduleNextIdleCall();
      }

      if (
        touchSystemArmed &&
        held[0] &&
        !prevHeld[0]
      ) {
        enterState(S_SOLO);
      }
      break;

    case S_SOLO:
      if (
        elapsed >= STAGE_MIN_MS &&
        held[1]
      ) {
        enterState(S_DUET);
        break;
      }

      if (held[0] && !prevHeld[0]) {
        triggerRecall(0);
      }
      break;

    case S_DUET:
      if (!held[2]) {
        if (e2ReleasedSince == 0) {
          e2ReleasedSince = now;
        }

        if (
          !e2Ready &&
          now - e2ReleasedSince >= E2_RELEASE_READY_MS
        ) {
          e2Ready = true;
          Serial.println("E2已准备：现在重新触摸即可进入CHORUS");
        }
      } else if (!e2Ready) {
        e2ReleasedSince = 0;
      }

      if (
        elapsed >= STAGE_MIN_MS &&
        e2Ready &&
        held[2] &&
        !prevHeld[2]
      ) {
        Serial.println("E2新触摸确认 → CHORUS / G33 / 03");
        enterState(S_CHORUS);
        break;
      }

      if (held[0] && !prevHeld[0]) {
        triggerRecall(0);
      }

      if (held[1] && !prevHeld[1]) {
        triggerRecall(1);
      }
      break;

    case S_CHORUS:
      if (!held[2]) {
        manualEndArmed = true;
        manualEndHeldSince = 0;
      }

      if (
        elapsed >= STAGE_MIN_MS &&
        chorusAudioFinished
      ) {
        enterState(S_FADEOUT);
        break;
      }

      if (
        elapsed >= STAGE_MIN_MS &&
        manualEndArmed &&
        held[2]
      ) {
        if (manualEndHeldSince == 0) {
          manualEndHeldSince = now;
        }

        if (now - manualEndHeldSince >= MANUAL_END_HOLD_MS) {
          enterState(S_FADEOUT);
          break;
        }
      } else if (!held[2]) {
        manualEndHeldSince = 0;
      }
      break;

    case S_FADEOUT:
      if (elapsed >= FADEOUT_MS) {
        enterState(S_BLACK);
      }
      break;

    case S_BLACK:
      if (
        USE_CODA_04 &&
        !coda04Played &&
        elapsed >= CODA_04_DELAY_MS
      ) {
        coda04Played = true;
        playTrack(4, 1);
      }

      if (
        USE_CODA_05 &&
        !coda05Played &&
        elapsed >= CODA_05_DELAY_MS
      ) {
        coda05Played = true;
        playTrack(5, 1);
      }

      if (held[0] && held[2]) {
        if (blackResetSince == 0) {
          blackResetSince = now;
        }

        if (now - blackResetSince >= BLACK_RESET_HOLD_MS) {
          enterState(S_IDLE);
        }
      } else {
        blackResetSince = 0;
      }
      break;
  }
}

void updateAndRenderCord(Cord &c) {
  for (int p = 0; p < MAX_PULSES; p++) {
    if (!c.pulses[p].alive) continue;

    c.pulses[p].pos += c.pulses[p].vel * dt;

    if (
      c.pulses[p].pos < -3.0f ||
      c.pulses[p].pos > c.n + 3.0f
    ) {
      c.pulses[p].alive = false;
    }
  }

  c.baseGlow += (
    c.glowTarget - c.baseGlow
  ) * min(1.0f, dt * 3.5f);

  for (int i = 0; i < c.n; i++) {
    float value = c.baseGlow;

    for (int p = 0; p < MAX_PULSES; p++) {
      if (!c.pulses[p].alive) continue;

      float distance = i - c.pulses[p].pos;
      value += c.pulses[p].intensity * expf(
        -(distance * distance) /
        (2.0f * PULSE_SIGMA * PULSE_SIGMA)
      );
    }

    value = constrain(value, 0.0f, 1.0f);

    c.leds[i] = c.color;
    c.leds[i].nscale8_video(
      (uint8_t)(value * 255.0f)
    );
  }
}

void setStageGlowTargets() {
  unsigned long elapsed = millis() - stateSince;

  float sharedBreath = raisedSine(SHARED_BREATH_PERIOD_MS);

  switch (state) {
    case S_IDLE:
      cords[0].glowTarget = 0.0f;
      cords[1].glowTarget = 0.0f;
      cords[2].glowTarget = 0.0f;
      island.glowTarget = 0.0f;
      break;

    case S_SOLO:
      if (elapsed < SOLO_BREATH_START_MS) {
        cords[0].glowTarget =
          0.052f + 0.008f * softPhaseSine(9000UL, 0UL);
      } else {
        cords[0].glowTarget =
          0.045f + 0.125f * sharedBreath;
      }

      cords[1].glowTarget = 0.0f;
      cords[2].glowTarget = 0.0f;
      island.glowTarget = 0.0f;
      break;

    case S_DUET: {
      float duet0 =
        0.90f + 0.10f * softPhaseSine(7200UL, 0UL);
      float duet1 =
        0.90f + 0.10f * softPhaseSine(7200UL, 3600UL);

      cords[0].glowTarget = 0.090f * duet0;
      cords[1].glowTarget = 0.090f * duet1;
      cords[2].glowTarget = 0.0f;
      island.glowTarget = 0.0f;
      break;
    }

    case S_CHORUS:
    case S_FADEOUT: {
      unsigned long breathEnd =
        CHORUS_BREATH_START_MS +
        CHORUS_BREATH_DURATION_MS;

      if (elapsed < CHORUS_BREATH_START_MS) {
        cords[0].glowTarget =
          0.090f + 0.012f * softPhaseSine(7600UL, 0UL);
        cords[1].glowTarget =
          0.090f + 0.012f * softPhaseSine(7600UL, 2500UL);
        cords[2].glowTarget =
          0.090f + 0.012f * softPhaseSine(7600UL, 5000UL);
      } else if (elapsed < breathEnd) {
        float sharedLevel =
          0.042f + 0.135f * sharedBreath;

        cords[0].glowTarget = sharedLevel;
        cords[1].glowTarget = sharedLevel;
        cords[2].glowTarget = sharedLevel;
      } else {
        cords[0].glowTarget =
          0.070f + 0.010f * softPhaseSine(11000UL, 0UL);
        cords[1].glowTarget =
          0.070f + 0.010f * softPhaseSine(11000UL, 3600UL);
        cords[2].glowTarget =
          0.070f + 0.010f * softPhaseSine(11000UL, 7200UL);
      }

      island.glowTarget = 0.0f;
      break;
    }

    case S_BLACK:
      cords[0].glowTarget = 0.0f;
      cords[1].glowTarget = 0.0f;
      cords[2].glowTarget = 0.0f;
      island.glowTarget = 0.0f;
      break;
  }
}

void updateStageChoreography() {
  unsigned long now = millis();
  unsigned long elapsed = now - stateSince;

  cobAccent *= max(0.0f, 1.0f - dt * 1.45f);

  uint8_t zone = 0;

  if (state == S_SOLO) {
    zone =
      (elapsed < SOLO_BREATH_START_MS) ? 1 : 2;
  } else if (state == S_DUET) {
    zone = 3;
  } else if (state == S_CHORUS) {
    unsigned long breathEnd =
      CHORUS_BREATH_START_MS +
      CHORUS_BREATH_DURATION_MS;

    if (elapsed < CHORUS_BREATH_START_MS) {
      zone = 4;
    } else if (elapsed < breathEnd) {
      zone = 5;
    } else {
      zone = 6;
    }
  } else {
    zone = 0;
  }

  if (zone != lightingTimelineZone) {
    lightingTimelineZone = zone;
    lightingSeqStep = 0;
    lightingSeqNextAt = now + 80UL;
  }

  if ((long)(now - lightingSeqNextAt) < 0) return;

  switch (zone) {
    case 1:
      if (lightingSeqStep == 0) {
        cobAccent = 0.30f;
        pulseIslandToPerson(0, 43.0f, 0.96f);
        lightingSeqStep = 1;
        lightingSeqNextAt = now + 3900UL;
      } else if (lightingSeqStep == 1) {
        pulsePersonToIsland(0, 39.0f, 0.70f);
        lightingSeqStep = 2;
        lightingSeqNextAt = now + 3900UL;
      } else {
        cobAccent = 0.34f;
        pulseIslandToPerson(0, 36.0f, 0.52f);
        lightingSeqStep = 0;
        lightingSeqNextAt = now + 4800UL;
      }
      break;

    case 2:
      if (lightingSeqStep == 0) {
        pulseIslandToPerson(0, 34.0f, 0.52f);
        lightingSeqStep = 1;
      } else {
        pulsePersonToIsland(0, 31.0f, 0.38f);
        lightingSeqStep = 0;
      }

      lightingSeqNextAt =
        now + SHARED_BREATH_PERIOD_MS / 2UL;
      break;

    case 3:
      if (lightingSeqStep == 0) {
        pulsePersonToIsland(1, 46.0f, 0.94f);
        lightingSeqStep = 1;
        lightingSeqNextAt = now + 2900UL;
      } else {
        cobAccent = 0.27f;
        pulseIslandToPerson(0, 41.0f, 0.72f);
        pulseIslandToPerson(1, 41.0f, 0.72f);
        lightingSeqStep = 0;
        lightingSeqNextAt = now + 5700UL;
      }
      break;

    case 4:
      if (lightingSeqStep == 0) {
        pulsePersonToIsland(0, 50.0f, 0.76f);
        pulsePersonToIsland(1, 50.0f, 0.76f);
        pulsePersonToIsland(2, 50.0f, 0.76f);
        lightingSeqStep = 1;
        lightingSeqNextAt = now + 3000UL;
      } else if (lightingSeqStep == 1) {
        cobAccent = 0.36f;
        pulseIslandToPerson(0, 44.0f, 0.68f);
        pulseIslandToPerson(1, 44.0f, 0.68f);
        pulseIslandToPerson(2, 44.0f, 0.68f);
        lightingSeqStep = 2;
        lightingSeqNextAt = now + 4000UL;
      } else {
        pulseIslandToPerson(0, 34.0f, 0.38f);
        pulsePersonToIsland(1, 34.0f, 0.38f);
        pulseIslandToPerson(2, 34.0f, 0.38f);
        lightingSeqStep = 0;
        lightingSeqNextAt = now + 4300UL;
      }
      break;

    case 5:
      if (lightingSeqStep == 0) {
        pulsePersonToIsland(0, 34.0f, 0.50f);
        pulsePersonToIsland(1, 34.0f, 0.50f);
        pulsePersonToIsland(2, 34.0f, 0.50f);
        lightingSeqStep = 1;
      } else {
        pulseIslandToPerson(0, 32.0f, 0.43f);
        pulseIslandToPerson(1, 32.0f, 0.43f);
        pulseIslandToPerson(2, 32.0f, 0.43f);
        lightingSeqStep = 0;
      }

      lightingSeqNextAt =
        now + SHARED_BREATH_PERIOD_MS / 2UL;
      break;

    case 6:
      if (lightingSeqStep == 0) {
        pulseIslandToPerson(0, 25.0f, 0.24f);
      } else if (lightingSeqStep == 1) {
        pulsePersonToIsland(1, 25.0f, 0.24f);
      } else {
        pulseIslandToPerson(2, 25.0f, 0.24f);
      }

      lightingSeqStep =
        (lightingSeqStep + 1) % 3;
      lightingSeqNextAt = now + 5200UL;
      break;

    default:
      lightingSeqNextAt = now + 1000UL;
      break;
  }
}

float fadeFactor() {
  if (state != S_FADEOUT) return 1.0f;

  float t = (float)(millis() - stateSince) / (float)FADEOUT_MS;
  return constrain(1.0f - t, 0.0f, 1.0f);
}

void scaleStrip(CRGB* leds, int count, float factor) {
  uint8_t scale = (uint8_t)(
    constrain(factor, 0.0f, 1.0f) * 255.0f
  );

  for (int i = 0; i < count; i++) {
    leds[i].nscale8_video(scale);
  }
}

void renderLights() {
  if (state == S_BLACK) {
    FastLED.clear(true);
    writePCA(CH_KEYES, 0.0f);
    writePCA(CH_COB, 0.0f);
    return;
  }

  setStageGlowTargets();

  updateStageChoreography();
  updateRecallEvents();

  updateAndRenderCord(cords[0]);
  updateAndRenderCord(cords[1]);
  updateAndRenderCord(cords[2]);
  updateAndRenderCord(island);

  float factor = fadeFactor();

  scaleStrip(ledsE0, NUM_E0, factor);
  scaleStrip(ledsE1, NUM_E1, factor);
  scaleStrip(ledsE2, NUM_E2, factor);
  scaleStrip(ledsIsland, NUM_ISLAND, factor);

  float keyesLevel = KEYES_IDLE;
  float cobLevel = COB_IDLE;
  unsigned long keyesPeriod = 8000UL;
  unsigned long cobPeriod = 6500UL;

  switch (state) {
    case S_IDLE:
      keyesLevel = KEYES_IDLE;
      cobLevel = COB_IDLE;
      keyesPeriod = 8500UL;
      break;

    case S_SOLO:
      keyesLevel = KEYES_SOLO;
      cobLevel = COB_SOLO;
      keyesPeriod = 6200UL;
      cobPeriod = 5200UL;
      break;

    case S_DUET:
      keyesLevel = KEYES_DUET;
      cobLevel = COB_DUET;
      keyesPeriod = 5000UL;
      cobPeriod = 4400UL;
      break;

    case S_CHORUS:
    case S_FADEOUT:
      keyesLevel = KEYES_CHORUS;
      cobLevel = COB_CHORUS;
      keyesPeriod = 4100UL;
      cobPeriod = 3700UL;
      break;

    default:
      break;
  }

  writePCA(
    CH_KEYES,
    keyesLevel * raisedSine(keyesPeriod) * factor
  );

  unsigned long stageElapsed =
    millis() - stateSince;

  float cobOutput = 0.0f;

  switch (state) {
    case S_IDLE:
    case S_BLACK:
      cobOutput = 0.0f;
      break;

    case S_SOLO:
      if (stageElapsed < SOLO_BREATH_START_MS) {
        cobOutput = 0.105f + cobAccent;
      } else {
        float breath =
          raisedSine(SHARED_BREATH_PERIOD_MS);
        cobOutput =
          0.075f + 0.390f * breath + cobAccent;
      }
      break;

    case S_DUET: {
      float duetBreath =
        0.82f + 0.18f * raisedSine(6500UL);
      cobOutput =
        0.180f * duetBreath + cobAccent;
      break;
    }

    case S_CHORUS:
    case S_FADEOUT: {
      unsigned long breathEnd =
        CHORUS_BREATH_START_MS +
        CHORUS_BREATH_DURATION_MS;

      if (stageElapsed < CHORUS_BREATH_START_MS) {
        cobOutput = 0.175f + cobAccent;
      } else if (stageElapsed < breathEnd) {
        float breath =
          raisedSine(SHARED_BREATH_PERIOD_MS);
        cobOutput =
          0.080f + 0.440f * breath + cobAccent;
      } else {
        cobOutput =
          0.135f +
          0.035f * raisedSine(12000UL) +
          cobAccent;
      }
      break;
    }
  }

  writePCA(
    CH_COB,
    constrain(cobOutput, 0.0f, 0.72f) * factor
  );

  FastLED.show();
}

void reportSerial() {
  if (millis() - lastSerialReport < SERIAL_REPORT_MS) return;
  lastSerialReport = millis();

  uint16_t f0 = capOK ? cap.filteredData(0) : 999;
  uint16_t f1 = capOK ? cap.filteredData(1) : 999;
  uint16_t f2 = capOK ? cap.filteredData(2) : 999;

  Serial.print("filt E0:");
  Serial.print(f0);
  Serial.print(" E1:");
  Serial.print(f1);
  Serial.print(" E2:");
  Serial.print(f2);

  Serial.print(" | held:");
  Serial.print(held[0] ? 1 : 0);
  Serial.print(held[1] ? 1 : 0);
  Serial.print(held[2] ? 1 : 0);

  Serial.print(" | armed:");
  Serial.print(touchSystemArmed ? 1 : 0);

  Serial.print(" | state:");
  Serial.print(stateName(state));

  Serial.print(" | E2ready:");
  Serial.print(e2Ready ? 1 : 0);

  unsigned long elapsedMs =
    millis() - stateSince;

  Serial.print(" | elapsed:");
  Serial.print(elapsedMs / 1000UL);
  Serial.print("s");

  Serial.print(" | lightZone:");
  Serial.print(lightingTimelineZone);
  Serial.println();
}

void setup() {
  Serial.begin(115200);
  delay(800);
  Serial.println();
  Serial.println("=== RECALL + COLOR + CODA FINAL / 160 LED STRIPS ===");

  Serial.println();
  Serial.println("==========================================");
  Serial.println("同林 / Of the Same Forest — FINAL");
  Serial.println("E0->G23 | E1->G21 | E2->G33 | COB=PCA9685 | G25不使用");
  Serial.print("TEST_MODE = ");
  Serial.println(TEST_MODE ? "true" : "false");
  Serial.println("==========================================");

  randomSeed(micros());

  Wire.begin(PIN_SDA, PIN_SCL);
  Wire.setClock(400000);

  pwm.begin();
  pwm.setPWMFreq(1000);
  writePCA(CH_KEYES, 0.0f);
  writePCA(CH_COB, 0.0f);

  capOK = cap.begin(0x5A);
  touchGuardUntil = millis() + STARTUP_GUARD_MS;
  touchSystemArmed = false;

  if (capOK) {
    Serial.println("MPR121 在线");
  } else {
    Serial.println("⚠️ MPR121 没找到：检查 SDA/SCL、3.3V 和 GND");
  }

  FastLED.addLeds<WS2812B, PIN_CORD_E0, GRB>(
    ledsE0,
    NUM_E0
  );

  FastLED.addLeds<WS2812B, PIN_CORD_E1, GRB>(
    ledsE1,
    NUM_E1
  );

  FastLED.addLeds<WS2812B, PIN_CORD_E2, GRB>(
    ledsE2,
    NUM_E2
  );

  FastLED.setBrightness(LED_MASTER);
  FastLED.clear(true);
  writePCA(CH_KEYES, 0.0f);
  writePCA(CH_COB, 0.0f);
  delay(80);
  FastLED.clear(true);

  initCord(cords[0], ledsE0, NUM_E0, COL_E0);
  initCord(cords[1], ledsE1, NUM_E1, COL_E1);
  initCord(cords[2], ledsE2, NUM_E2, COL_E2);
  initCord(
    island,
    ledsIsland,
    NUM_ISLAND,
    COL_ISLAND_IDLE
  );

  dfSerial.begin(
    9600,
    SERIAL_8N1,
    DF_RX_PIN,
    DF_TX_PIN
  );

  delay(1800);

  dfplayer.begin(dfSerial, false, false);
  dfOK = true;

  dfplayer.outputDevice(DFPLAYER_DEVICE_SD);
  delay(300);
  dfplayer.volume(DF_VOLUME);
  delay(300);

  Serial.println("DFPlayer 无ACK模式已启用");
  Serial.println("主音轨：E0=/01/001.mp3，E1=/02/001.mp3，E2=/03/001.mp3");
  Serial.println("追加呼喊：/ADVERT/0001.mp3 与 /ADVERT/0002.mp3");
  Serial.println("黑场：/04/001.mp3 → /05/001.mp3");

  lastFrame = millis();
  enterState(S_IDLE);
}

void loop() {
  unsigned long now = millis();

  dt = (now - lastFrame) / 1000.0f;
  dt = constrain(dt, 0.0f, 0.05f);
  lastFrame = now;

  readTouch();
  pollAudio();
  updateStateMachine();
  renderLights();
  reportSerial();
}
